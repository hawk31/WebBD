-- Articulos de la marca Playmobil

SELECT numref,nombre
FROM ARTICULO 
WHERE deMarca = 'Playmobil'

-- Artículos cuya descripción de marca sea más breve de 140 caracteres

SELECT numref, nombre
FROM ARTICULO INNER JOIN MARCA ON (ARTICULO.deMarca = MARCA.nombre)
WHERE len(MARCA.desc) < 140

-- Articulos de piezas cuyo stock de alguna pieza sea menor que 20

SELECT deArt
FROM PIEZAS INNER JOIN PIEZASvsL ON (PIEZAS.deArt=PIEZASvsL.dePieza)
WHERE stock < 20

-- Articulos relacionados con la muñeca de Famosa


SELECT deArt1, deArt2
FROM ARTREL WHERE deArt1 = (SELECT numref	
	FROM ARTICULO
	WHERE nombre = 'Muñeca Famosa') OR deArt2 = (SELECT numref	
												FROM ARTICULO
												WHERE nombre = 'Muñeca Famosa')

-- Ruta de las imágenes relacionadas con el T-Rex

SELECT rutaimg
FROM (IMAGEN INNER JOIN MEDIA ON (MEDIA.idMedia = IMAGEN.deMedia)) INNER JOIN
		ARTICULO ON (MEDIA.deArt = ARTICULO.numref)
WHERE ARTICULO.nombre = 'T-Rex'

-- Comentarios sobre Lego Creator 

SELECT email,comentario
FROM COMENTARIO INNER JOIN ARTICULO ON (COMENTARIO.deArt = ARTICULO.numref)
WHERE ARTICULO.nombre = 'Lego Creator'

-- Ilustraciones sobre la pieza "e22" del artículo Lego Batman Car 

SELECT idIlus
FROM ((ILUS INNER JOIN LPIEZA ON (ILUS.deLpieza = LPIEZA.idPieza))
	INNER JOIN PIEZASvsL ON (PIEZASvsL.deLPieza = LPIEZA.idPieza))
	INNER JOIN PIEZAS ON (PIEZASvsL.dePieza = PIEZASvsL.deArt)
	INNER JOIN ARTICULO ON (ARTICULO.numref = PIEZAS.deArt)
	WHERE ARTICULO.nombre = 'Lego Batman Car' AND
	LPIEZA.idPieza = 'e22'

-- Teléfonos asociados al cliente Juan Martín

SELECT telefono
FROM TELEFONO INNER JOIN CLIENTE ON (TELEFONO.deCliente = CLIENTE.usuario)
WHERE CLIENTE.nombre = 'Juan Martín'

-- Direcciones pertenecientes a Madrid cuyo nombre empiece por "c"
SELECT calle, codPostal, país
FROM DIRECCION 
WHERE provincia = 'Madrid' AND calle LIKE 'C%'

-- Pedidos en los que se haya comprado un muñeco de Spiderman
SELECT PEDIDO.idPedido
FROM LPEDIDO INNER JOIN PEDIDO ON (PEDIDO.idPedido = LPEDIDO.dePedido)
WHERE LPEDIDO.deArt IN (SELECT numref
						FROM ARTICULO
						WHERE nombre = 'Muñeco Spiderman')

-- Pedidos que se hayan realizado con el complemento "papel de regalo"

SELECT dePedido
FROM COMPvsPED
WHERE deComp = 'Papel de Regalo'

-- Alertas asociadas a un determinado pedido 

SELECT estado, fecha
FROM ALERTAS 
WHERE dePedido = '1310239e7y'

-- Instrucciones de los artículos cuya edad maxima sea 12 años.

SELECT idIns, rutaIns
FROM INSTRUC 
WHERE dePieza IN (SELECT numref
					FROM ARTICULO
					WHERE edadmax = 12)

-- Pedidos cuyo pago haya sido con tarjeta

SELECT idPedido
FROM (PEDIDO INNER JOIN PAGO ON (PEDIDO.idPedido = PAGO.dePedido))
	INNER JOIN TPAGO ON (PAGO.deTpago = TPAGO.tipo)
	WHERE TPAGO.tipo = 'tarjeta'

-- Blogs que se hayan escrito durante el año 2012

SELECT idBlog
FROM BLOG 
WHERE fecha BETWEEN '2012-1-1' AND '2012-12-31'

-- Imagenes cuyo artículo asociado tenga un precio inferior a 20€

SELECT IMAGEN.id, IMAGEN.rutaimg
FROM (IMAGEN INNER JOIN MEDIA ON (MEDIA.idMedia = IMAGEN.deMedia))
	INNER JOIN ARTICULO ON (ARTICULO.numref = MEDIA.deArt))
WHERE ARTICULO.precio < 20

-- Artículos que tengan un comentario con un email que empiece por "e"

SELECT ARTICULO.numref, ARTICULO.nombre
FROM ARTICULO INNER JOIN COMENTARIO ON (ARTICULO.numref = COMENTARIO.deArt)
WHERE COMENTARIO.email LIKE 'e%'

-- Estado y fecha ordenados de una alerta de los pedidos cuyo cliente sea Juan Martín

SELECT ALERTAS.estado, ALERTAS.fecha
FROM (ALERTAS INNER JOIN PEDIDO ON (PEDIDO.idPedido = ALERTAS.dePedido))
	INNER JOIN CLIENTE ON (PEDIDO.deCliente = CLIENTE.usuario)
WHERE CLIENTE.nombre = 'Juan Martín'
ORDER BY ALERTAS.fecha ASC 

-- Seleccionar los artículos que no tengan artículos relacionados 

SELECT numref, nombre
FROM ARTICULO 
WHERE NOT EXISTS (SELECT *
				FROM ARTREL
				WHERE ARTICULO.numref = ARTREL.deArt1 OR ARTICULO.numref = ARTREL.deArt2 )


-- [Propuesta] Obtener artículos de la marca Lego (nombre de artículo y descripción de la colección) 
-- vendidos a más de 50 clientes (mostrar en la consulta también el número de
-- clientes como “numClientes”), ordenados de forma decreciente por número de clientes.

SELECT ARTICULO.numref, count(LPEDIDO.deArt) AS numClientes
FROM ARTICULO INNER JOIN LPEDIDO ON (ARTICULO.numref = LPEDIDO.deArt)
WHERE ARTICULO.deMarca = 'Lego'
GROUP BY ARTICULO.numref
HAVING count(LPEDIDO.deArt)>50 
ORDER BY numClientes DESC

-- [Propuesta] Obtener los nombres de artículos que se 
-- encuentren como Novedad este mes y no pertenezcan a ninguna colección
-- (sin emplear EXISTS).

SELECT NOVEDAD.idNovedad, ARTICULO.nombre
FROM NOVEDAD INNER JOIN ARTICULO ON (NOVEDAD.deArt = ARTICULO.numref)
WHERE (NOVEDAD.fechaNovedad BETWEEN CONCAT(extract(YEAR_MONTH FROM now()),'-1') AND 
	DATE_ADD(CONCAT(extract(YEAR_MONTH FROM now()),'-1'),INTERVAL 1 MONTH)	) AND
	NOVEDAD.deCol IS NULL 						


-- Nombres de artículos que se hayan vendido más de 20 veces

SELECT nombre
FROM ARTICULO
WHERE numref IN (
				SELECT deArt
				FROM LPEDIDO
				GROUP BY deArt
				HAVING sum(cantidad) > 20)

-- Artículos que no figuren en más de una categoría

SELECT nombre
FROM ARTICULO
WHERE numref IN (SELECT deArt
				FROM CATvsART 
				GROUP BY deArt
				HAVING count(deCat) < 2 )

-- Artículos vendidos que superen la media en cantidad de artículos vendidos

SELECT nombre FROM ARTICULO WHERE numref IN(
	SELECT LPEDIDO.deArt
	FROM LPEDIDO 
	GROUP BY LPEDIDO.deArt
	HAVING sum(LPEDIDO.cantidad) > (SELECT avg(cantidad)
									FROM LPEDIDO))

-- Rizando el rizo de lo anterior: Artículos vendidos cuyo numref sea menor que
-- alguno de aquellos cuya cantidad vendida supere la media 

SELECT nombre FROM ARTICULO WHERE numref < ANY(
	SELECT LPEDIDO.deArt
	FROM LPEDIDO 
	GROUP BY LPEDIDO.deArt
	HAVING sum(LPEDIDO.cantidad) > (SELECT avg(cantidad)
									FROM LPEDIDO))

-- Pedidos de clientes residentes en Barcelona que hayan realizado un
-- pedido con envío express en las últimas 24h

SELECT idPedido
FROM PEDIDO
WHERE deCliente IN (
	SELECT usuario
	FROM CLIENTE INNER JOIN JOIN DIRECCION ON (CLIENTE.usuario = DIRECCION.deCliente)
	WHERE DIRECCION.provincia = 'Barcelona')
AND extract(DAY fecha) = extract(DAY now()) 

